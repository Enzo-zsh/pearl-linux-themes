#!/bin/sh

glib-compile-resources gnome-shell-theme.gresource.xml
